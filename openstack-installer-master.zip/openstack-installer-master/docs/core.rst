``cloudinstall.core`` --- Core logic
========================================

.. automodule:: cloudinstall.core
    :members:
    :undoc-members:
    :show-inheritance:
