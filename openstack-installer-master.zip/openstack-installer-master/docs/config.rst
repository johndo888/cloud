``cloudinstall.config`` --- Config
========================================

.. automodule:: cloudinstall.config
    :members:
    :undoc-members:
    :show-inheritance:
