NAME
====

openstack-uninstall - Ubuntu OpenStack Installer Documentation

SYNOPSIS
========

usage: sudo openstack-uninstall

DESCRIPTION
===========

Uninstalls any existing deployed cloud.
