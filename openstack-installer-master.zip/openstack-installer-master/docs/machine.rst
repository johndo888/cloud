``cloudinstall.machine`` --- Maas/Juju machine representation
=============================================================

.. automodule:: cloudinstall.machine
    :noindex:
    :members:
    :undoc-members:
    :show-inheritance:
