``cloudinstall.placement.controller`` --- machine placement in MAAS
===================================================================

.. automodule:: cloudinstall.placement.controller
    :members:
    :undoc-members:
    :show-inheritance:


``cloudinstall.placement.ui`` --- UI for machine placement in MAAS
==================================================================

.. automodule:: cloudinstall.placement.ui
    :members:
    :undoc-members:
    :show-inheritance:
