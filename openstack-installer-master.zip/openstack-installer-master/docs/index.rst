Ubuntu OpenStack Installer
==========================

NOTICE: Documentation moved to http://openstack.astokes.org/
============================================================
