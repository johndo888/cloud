``cloudinstall.service`` --- Service Interface
==============================================

.. automodule:: cloudinstall.service
    :noindex:
    :members:
    :undoc-members:
    :show-inheritance:
