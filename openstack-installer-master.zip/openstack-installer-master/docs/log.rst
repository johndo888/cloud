``cloudinstall.log`` --- Log Interface
========================================

.. automodule:: cloudinstall.log
    :members:
    :undoc-members:
    :show-inheritance:

