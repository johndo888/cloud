``cloudinstall.ui`` --- UI Widgets
==================================

.. automodule:: cloudinstall.ui
    :noindex:
    :members:
    :undoc-members:
    :show-inheritance:
