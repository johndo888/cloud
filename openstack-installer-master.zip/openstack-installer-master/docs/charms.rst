``cloudinstall.charms`` --- Juju Charm
======================================

.. automodule:: cloudinstall.charms
    :noindex:
    :members:
    :undoc-members:
    :show-inheritance:
